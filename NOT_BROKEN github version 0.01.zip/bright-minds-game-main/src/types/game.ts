// Game state and level types for NOT BROKEN

export interface GameState {
  currentLevel: number;
  sparks: number;
  completedLevels: number[];
  isPlaying: boolean;
}

export interface Level {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  thought: string;
  message: string;
  colorClass: string;
  icon: string;
}

export const LEVELS: Level[] = [
  {
    id: 1,
    title: "Classroom",
    subtitle: "School Room",
    description: "Letters dance on the board. Words move and shift.",
    thought: "I am trying...",
    message: "The world feels noisy. But you are listening in your own way.",
    colorClass: "bg-classroom",
    icon: "📚",
  },
  {
    id: 2,
    title: "Hallway",
    subtitle: "Flip the World",
    description: "Signs and arrows seem backwards. Everything moves.",
    thought: "My mind is fast. I think different.",
    message: "Sometimes seeing things differently is a superpower.",
    colorClass: "bg-hallway",
    icon: "🔄",
  },
  {
    id: 3,
    title: "Exam Room",
    subtitle: "Be Fast. Be Quiet.",
    description: "The clock feels heavy. Time moves strange.",
    thought: "I know this. I just can't show it yet.",
    message: "Your knowledge is real, even when tests don't show it.",
    colorClass: "bg-exam",
    icon: "⏰",
  },
  {
    id: 4,
    title: "Break Room",
    subtitle: "Free Time",
    description: "Colors, blocks, art supplies. Freedom to create.",
    thought: "Here, I feel good.",
    message: "Everyone has a place where they shine.",
    colorClass: "bg-breakroom",
    icon: "🎨",
  },
  {
    id: 5,
    title: "Smart Test",
    subtitle: "Pattern Puzzles",
    description: "No words needed. Just shapes and thinking.",
    thought: "No reading. Just thinking.",
    message: "Intelligence has many forms. This is yours.",
    colorClass: "bg-puzzle",
    icon: "🧩",
  },
  {
    id: 6,
    title: "Future Paths",
    subtitle: "Three Futures",
    description: "See what different minds can become.",
    thought: "We are all smart. We are all different.",
    message: "Different brain. Different strength. NOT BROKEN.",
    colorClass: "bg-future",
    icon: "✨",
  },
];

export const FINAL_MESSAGES = [
  "ADHD is not low IQ",
  "Dyslexia is not lazy",
  "Different brain. Different strength.",
  "NOT BROKEN",
];

export const FUTURE_PATHS = [
  {
    name: "The Scientist",
    description: "Asks questions others don't think to ask",
    icon: "🔬",
    trait: "Curiosity",
  },
  {
    name: "The Engineer",
    description: "Builds and fixes, sees how things work",
    icon: "⚙️",
    trait: "Problem Solving",
  },
  {
    name: "The Entrepreneur",
    description: "Starts new ideas, thinks big",
    icon: "💡",
    trait: "Creativity",
  },
];
