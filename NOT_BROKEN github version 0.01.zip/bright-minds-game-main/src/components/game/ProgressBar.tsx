import { motion } from 'framer-motion';

interface ProgressBarProps {
  current: number;
  total: number;
  showLabel?: boolean;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ current, total, showLabel = true }) => {
  const percentage = (current / total) * 100;

  return (
    <div className="w-full max-w-md mx-auto">
      {showLabel && (
        <div className="flex justify-between mb-2 text-sm text-muted-foreground">
          <span>Progress</span>
          <span>{current} of {total}</span>
        </div>
      )}
      <div className="spark-progress">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="spark-progress-fill"
        />
      </div>
    </div>
  );
};

export default ProgressBar;
