import { motion, AnimatePresence } from 'framer-motion';
import { useGame } from '@/context/GameContext';
import GuideOrb from './GuideOrb';
import GameButton from './GameButton';
import { LEVELS } from '@/types/game';

// Level components
import ClassroomLevel from './levels/ClassroomLevel';
import HallwayLevel from './levels/HallwayLevel';
import ExamLevel from './levels/ExamLevel';
import BreakRoomLevel from './levels/BreakRoomLevel';
import PuzzleLevel from './levels/PuzzleLevel';
import FutureLevel from './levels/FutureLevel';

interface GameScreenProps {
  onBackToMenu: () => void;
  onComplete: () => void;
}

const GameScreen: React.FC<GameScreenProps> = ({ onBackToMenu, onComplete }) => {
  const { gameState, completeLevel, goToLevel } = useGame();

  const handleLevelComplete = () => {
    completeLevel(gameState.currentLevel);
    
    if (gameState.currentLevel >= 6) {
      onComplete();
    } else {
      goToLevel(gameState.currentLevel + 1);
    }
  };

  const renderLevel = () => {
    switch (gameState.currentLevel) {
      case 1:
        return <ClassroomLevel onComplete={handleLevelComplete} />;
      case 2:
        return <HallwayLevel onComplete={handleLevelComplete} />;
      case 3:
        return <ExamLevel onComplete={handleLevelComplete} />;
      case 4:
        return <BreakRoomLevel onComplete={handleLevelComplete} />;
      case 5:
        return <PuzzleLevel onComplete={handleLevelComplete} />;
      case 6:
        return <FutureLevel onComplete={handleLevelComplete} />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen relative">
      {/* Back button */}
      <motion.button
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        onClick={onBackToMenu}
        className="fixed top-4 left-4 z-50 bg-card/80 backdrop-blur-sm rounded-full px-4 py-2 shadow-game hover:shadow-game-hover transition-all flex items-center gap-2"
      >
        <span>←</span>
        <span className="text-sm text-foreground/70">Menu</span>
      </motion.button>

      {/* Level indicator */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="fixed top-4 left-1/2 -translate-x-1/2 z-40"
      >
        <div className="bg-card/80 backdrop-blur-sm rounded-full px-4 py-2 shadow-game flex items-center gap-2">
          <span className="text-lg">{LEVELS[gameState.currentLevel - 1]?.icon}</span>
          <span className="font-display text-sm text-foreground/70">
            {gameState.currentLevel} / 6
          </span>
        </div>
      </motion.div>

      {/* Pause/Skip button */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="fixed bottom-4 right-4 z-50"
      >
        <GameButton variant="skip" size="sm" onClick={handleLevelComplete}>
          Skip Level →
        </GameButton>
      </motion.div>

      {/* Current level */}
      <AnimatePresence mode="wait">
        <motion.div
          key={gameState.currentLevel}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
        >
          {renderLevel()}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default GameScreen;
