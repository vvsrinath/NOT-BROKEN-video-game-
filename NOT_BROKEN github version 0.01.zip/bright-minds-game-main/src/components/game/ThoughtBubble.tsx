import { motion } from 'framer-motion';

interface ThoughtBubbleProps {
  thought: string;
  delay?: number;
}

const ThoughtBubble: React.FC<ThoughtBubbleProps> = ({ thought, delay = 0 }) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ delay, duration: 0.5, ease: "easeOut" }}
      className="thought-bubble max-w-sm mx-auto"
    >
      <p className="text-lg text-foreground/80 italic text-center">
        "{thought}"
      </p>
    </motion.div>
  );
};

export default ThoughtBubble;
