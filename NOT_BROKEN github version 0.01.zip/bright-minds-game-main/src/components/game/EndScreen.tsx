import { motion } from 'framer-motion';
import { useGame } from '@/context/GameContext';
import GameButton from './GameButton';
import GuideOrb from './GuideOrb';
import ProgressBar from './ProgressBar';
import { FINAL_MESSAGES } from '@/types/game';

interface EndScreenProps {
  onRestart: () => void;
  onAwareness: () => void;
}

const EndScreen: React.FC<EndScreenProps> = ({ onRestart, onAwareness }) => {
  const { gameState } = useGame();

  return (
    <div className="min-h-screen bg-gradient-to-b from-future/40 via-background to-spark/10 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Celebration particles */}
      <div className="absolute inset-0 pointer-events-none">
        {[...Array(30)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ 
              opacity: 0, 
              y: -20,
              x: Math.random() * window.innerWidth,
            }}
            animate={{ 
              opacity: [0, 1, 0],
              y: window.innerHeight + 20,
              rotate: 360,
            }}
            transition={{ 
              duration: 4 + Math.random() * 3,
              delay: Math.random() * 3,
              repeat: Infinity,
            }}
            className="absolute text-2xl"
          >
            {['✨', '🌟', '💫', '⭐'][Math.floor(Math.random() * 4)]}
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative z-10 text-center max-w-2xl mx-auto space-y-8"
      >
        <GuideOrb showMessage message="You completed the journey!" />

        <motion.h1
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.3, type: "spring" }}
          className="font-display text-5xl md:text-7xl text-spark font-bold"
        >
          NOT BROKEN
        </motion.h1>

        <div className="space-y-4">
          {FINAL_MESSAGES.map((message, i) => (
            <motion.p
              key={message}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 + i * 0.3 }}
              className="font-display text-xl text-foreground/80"
            >
              {message}
            </motion.p>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2 }}
          className="bg-card/80 backdrop-blur-sm rounded-3xl p-8 shadow-game"
        >
          <p className="text-muted-foreground mb-4">Total Sparks Collected</p>
          <div className="flex items-center justify-center gap-3">
            <span className="text-5xl spark-glow">✨</span>
            <span className="font-display text-5xl text-spark font-bold">
              {gameState.sparks}
            </span>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2.5 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <GameButton variant="primary" onClick={onRestart}>
            Play Again 🎮
          </GameButton>
          <GameButton variant="secondary" onClick={onAwareness}>
            Learn More 📚
          </GameButton>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default EndScreen;
