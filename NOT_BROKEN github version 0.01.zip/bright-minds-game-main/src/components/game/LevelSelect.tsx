import { motion } from 'framer-motion';
import { useGame } from '@/context/GameContext';
import GameButton from './GameButton';
import GuideOrb from './GuideOrb';
import LevelCard from './LevelCard';
import { LEVELS } from '@/types/game';

interface LevelSelectProps {
  onLevelSelect: (levelId: number) => void;
  onBack: () => void;
}

const LevelSelect: React.FC<LevelSelectProps> = ({ onLevelSelect, onBack }) => {
  const { gameState } = useGame();

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-muted/20 to-background py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <GameButton variant="skip" onClick={onBack} className="mb-6">
            ← Back
          </GameButton>
          
          <h1 className="font-display text-3xl md:text-4xl text-foreground mb-2">
            Choose Your Chapter
          </h1>
          <p className="text-foreground/60">
            {gameState.completedLevels.length} of 6 completed
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-4">
          {LEVELS.map((level, index) => (
            <LevelCard
              key={level.id}
              level={level}
              index={index}
              onClick={() => onLevelSelect(level.id)}
            />
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="mt-8 text-center"
        >
          <GuideOrb showMessage message="Each chapter is a new experience. No wrong choices!" />
        </motion.div>
      </div>
    </div>
  );
};

export default LevelSelect;
