import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface GameButtonProps {
  variant?: 'primary' | 'secondary' | 'skip' | 'spark';
  size?: 'sm' | 'md' | 'lg';
  children: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
  type?: 'button' | 'submit' | 'reset';
}

const GameButton: React.FC<GameButtonProps> = ({
  variant = 'primary',
  size = 'md',
  className,
  children,
  onClick,
  disabled,
  type = 'button',
}) => {
  const baseClasses = "font-display font-bold rounded-full transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed";
  
  const variants = {
    primary: "bg-primary text-primary-foreground hover:brightness-110 shadow-game hover:shadow-game-hover",
    secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80 shadow-game",
    skip: "bg-muted text-muted-foreground hover:bg-muted/80",
    spark: "bg-gradient-to-r from-spark to-primary text-spark-foreground hover:brightness-110 shadow-glow",
  };

  const sizes = {
    sm: "px-4 py-2 text-sm",
    md: "px-6 py-3 text-base",
    lg: "px-8 py-4 text-lg",
  };

  return (
    <motion.button
      type={type}
      whileHover={disabled ? {} : { scale: 1.02 }}
      whileTap={disabled ? {} : { scale: 0.98 }}
      className={cn(baseClasses, variants[variant], sizes[size], className)}
      onClick={onClick}
      disabled={disabled}
    >
      {children}
    </motion.button>
  );
};

export default GameButton;
