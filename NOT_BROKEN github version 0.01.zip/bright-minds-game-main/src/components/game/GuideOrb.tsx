import { motion } from 'framer-motion';

interface GuideOrbProps {
  message?: string;
  showMessage?: boolean;
}

const GuideOrb: React.FC<GuideOrbProps> = ({ message, showMessage = false }) => {
  return (
    <div className="flex flex-col items-center gap-4">
      <motion.div
        animate={{
          y: [0, -8, 0],
          scale: [1, 1.05, 1],
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut",
        }}
        className="relative"
      >
        {/* Glow effect */}
        <div className="absolute inset-0 rounded-full bg-secondary/50 blur-xl scale-150" />
        
        {/* Main orb */}
        <div className="relative w-16 h-16 rounded-full bg-gradient-to-br from-secondary via-accent to-secondary flex items-center justify-center shadow-glow">
          {/* Inner glow */}
          <div className="absolute inset-2 rounded-full bg-card/30 blur-sm" />
          
          {/* Eyes */}
          <div className="relative flex gap-2">
            <motion.div
              animate={{ scale: [1, 0.9, 1] }}
              transition={{ duration: 3, repeat: Infinity }}
              className="w-2 h-2 rounded-full bg-foreground/70"
            />
            <motion.div
              animate={{ scale: [1, 0.9, 1] }}
              transition={{ duration: 3, repeat: Infinity, delay: 0.1 }}
              className="w-2 h-2 rounded-full bg-foreground/70"
            />
          </div>
        </div>
      </motion.div>

      {showMessage && message && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="bg-card/80 backdrop-blur-sm rounded-2xl px-4 py-2 max-w-xs text-center shadow-game"
        >
          <p className="text-sm text-foreground/80">{message}</p>
        </motion.div>
      )}
    </div>
  );
};

export default GuideOrb;
