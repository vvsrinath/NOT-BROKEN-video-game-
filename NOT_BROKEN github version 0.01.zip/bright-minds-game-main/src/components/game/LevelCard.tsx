import { motion } from 'framer-motion';
import { Level } from '@/types/game';
import { useGame } from '@/context/GameContext';

interface LevelCardProps {
  level: Level;
  index: number;
  onClick: () => void;
}

const LevelCard: React.FC<LevelCardProps> = ({ level, index, onClick }) => {
  const { gameState } = useGame();
  const isCompleted = gameState.completedLevels.includes(level.id);
  const isUnlocked = level.id <= gameState.completedLevels.length + 1;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      whileHover={isUnlocked ? { scale: 1.02 } : {}}
      whileTap={isUnlocked ? { scale: 0.98 } : {}}
      onClick={isUnlocked ? onClick : undefined}
      className={`level-card ${level.colorClass} ${
        isUnlocked ? 'cursor-pointer' : 'opacity-60 cursor-not-allowed'
      } ${isCompleted ? 'ring-2 ring-spark' : ''}`}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-3xl">{level.icon}</span>
            {isCompleted && (
              <motion.span
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="text-spark text-xl"
              >
                ✓
              </motion.span>
            )}
          </div>
          <h3 className="font-display text-xl font-bold text-foreground mb-1">
            {level.title}
          </h3>
          <p className="text-sm text-foreground/70 mb-2">{level.subtitle}</p>
          <p className="text-sm text-foreground/60">{level.description}</p>
        </div>
      </div>

      {!isUnlocked && (
        <div className="absolute inset-0 rounded-2xl bg-foreground/10 flex items-center justify-center">
          <span className="text-2xl">🔒</span>
        </div>
      )}
    </motion.div>
  );
};

export default LevelCard;
