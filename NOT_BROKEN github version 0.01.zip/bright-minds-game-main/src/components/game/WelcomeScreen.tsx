import { motion } from 'framer-motion';
import GameButton from './GameButton';
import GuideOrb from './GuideOrb';

interface WelcomeScreenProps {
  onStart: () => void;
  onLevelSelect: () => void;
  onAwareness: () => void;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onStart, onLevelSelect, onAwareness }) => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-muted/30 to-background flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0 }}
            animate={{ 
              opacity: [0.1, 0.3, 0.1],
              y: [0, -20, 0],
            }}
            transition={{ 
              duration: 4 + i * 0.5,
              delay: i * 0.3,
              repeat: Infinity,
            }}
            className="absolute rounded-full"
            style={{
              width: 80 + Math.random() * 100,
              height: 80 + Math.random() * 100,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              background: `radial-gradient(circle, hsl(var(--${
                ['primary', 'secondary', 'accent', 'spark'][Math.floor(Math.random() * 4)]
              }) / 0.15), transparent)`,
            }}
          />
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative z-10 text-center max-w-2xl mx-auto"
      >
        {/* Guide orb greeting */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.3, type: "spring" }}
          className="mb-8"
        >
          <GuideOrb />
        </motion.div>

        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mb-6"
        >
          <h1 className="font-display text-5xl md:text-7xl text-foreground mb-2 tracking-tight">
            NOT BROKEN
          </h1>
          <p className="text-xl md:text-2xl text-spark font-display">
            Learning Differently
          </p>
        </motion.div>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="text-lg text-foreground/70 mb-10 max-w-md mx-auto"
        >
          A journey through school, through challenges, and into a bright future. 
          Different brain. Different strength.
        </motion.p>

        {/* Action buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
          className="flex flex-col sm:flex-row gap-4 justify-center mb-8"
        >
          <GameButton variant="spark" size="lg" onClick={onStart}>
            ✨ Start Journey
          </GameButton>
          <GameButton variant="secondary" size="lg" onClick={onLevelSelect}>
            📖 Choose Chapter
          </GameButton>
        </motion.div>

        {/* Awareness link */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.1 }}
        >
          <GameButton variant="skip" onClick={onAwareness}>
            For Teachers & Parents →
          </GameButton>
        </motion.div>

        {/* Features */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.3 }}
          className="mt-12 flex flex-wrap justify-center gap-4 text-sm text-foreground/50"
        >
          <span className="flex items-center gap-2">
            <span>✓</span> No failure
          </span>
          <span className="flex items-center gap-2">
            <span>✓</span> No timers
          </span>
          <span className="flex items-center gap-2">
            <span>✓</span> Always positive
          </span>
          <span className="flex items-center gap-2">
            <span>✓</span> Skip anytime
          </span>
        </motion.div>
      </motion.div>
    </div>
  );
};

export default WelcomeScreen;
