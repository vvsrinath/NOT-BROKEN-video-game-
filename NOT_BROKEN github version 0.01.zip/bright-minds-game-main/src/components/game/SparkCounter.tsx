import { motion } from 'framer-motion';
import { useGame } from '@/context/GameContext';

const SparkCounter = () => {
  const { gameState } = useGame();

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed top-4 right-4 z-50"
    >
      <div className="flex items-center gap-2 bg-card/90 backdrop-blur-sm rounded-full px-4 py-2 shadow-game">
        <motion.span
          key={gameState.sparks}
          initial={{ scale: 1.3 }}
          animate={{ scale: 1 }}
          className="text-2xl spark-glow"
        >
          ✨
        </motion.span>
        <span className="font-display text-xl font-bold text-spark">
          {gameState.sparks}
        </span>
        <span className="text-sm text-muted-foreground">Sparks</span>
      </div>
    </motion.div>
  );
};

export default SparkCounter;
