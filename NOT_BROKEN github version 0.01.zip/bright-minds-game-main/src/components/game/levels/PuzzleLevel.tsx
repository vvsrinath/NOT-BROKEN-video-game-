import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGame } from '@/context/GameContext';
import ThoughtBubble from '../ThoughtBubble';
import GameButton from '../GameButton';

interface PuzzleLevelProps {
  onComplete: () => void;
}

const shapes = [
  { id: 1, shape: "square", color: "bg-blue-400", match: 4 },
  { id: 2, shape: "circle", color: "bg-green-400", match: 5 },
  { id: 3, shape: "triangle", color: "bg-orange-400", match: 6 },
];

const targets = [
  { id: 4, shape: "square", color: "border-blue-400" },
  { id: 5, shape: "circle", color: "border-green-400" },
  { id: 6, shape: "triangle", color: "border-orange-400" },
];

const PuzzleLevel: React.FC<PuzzleLevelProps> = ({ onComplete }) => {
  const { addSparks } = useGame();
  const [step, setStep] = useState(0);
  const [matched, setMatched] = useState<number[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [interacted, setInteracted] = useState(false);

  const handleShapeClick = (id: number) => {
    setSelected(id);
  };

  const handleTargetClick = (targetId: number) => {
    if (selected !== null) {
      const shape = shapes.find(s => s.id === selected);
      if (shape && shape.match === targetId) {
        setMatched([...matched, targetId]);
        addSparks(5);
      }
      setSelected(null);
    }
  };

  const allMatched = matched.length === 3;

  useEffect(() => {
    if (step === 2 && !interacted) {
      addSparks(15);
      setInteracted(true);
    }
  }, [step, interacted, addSparks]);

  const ShapeComponent: React.FC<{ shape: string; className: string }> = ({ shape, className }) => {
    if (shape === "square") {
      return <div className={`w-12 h-12 rounded-lg ${className}`} />;
    }
    if (shape === "circle") {
      return <div className={`w-12 h-12 rounded-full ${className}`} />;
    }
    return (
      <div 
        className={className}
        style={{
          width: 0,
          height: 0,
          borderLeft: "24px solid transparent",
          borderRight: "24px solid transparent",
          borderBottom: "48px solid currentColor",
        }}
      />
    );
  };

  return (
    <div className="min-h-screen bg-puzzle/30 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-4 rounded-3xl bg-gradient-to-br from-puzzle/40 to-secondary/50" />

      <div className="relative z-10 text-center max-w-2xl mx-auto">
        <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.div
              key="intro"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-6"
            >
              <h2 className="font-display text-3xl md:text-4xl text-foreground">
                🧩 Smart Puzzle Test
              </h2>
              <p className="text-lg text-foreground/70">
                No words. No writing. Just thinking with shapes.
              </p>
              <GameButton onClick={() => setStep(1)}>Begin</GameButton>
            </motion.div>
          )}

          {step === 1 && (
            <motion.div
              key="puzzle"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              <ThoughtBubble thought="No reading. Just thinking." delay={0} />

              {/* Shapes to match */}
              <div className="flex justify-center gap-6 mb-8">
                {shapes.map((shape) => (
                  <motion.button
                    key={shape.id}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => handleShapeClick(shape.id)}
                    className={`p-4 rounded-xl transition-all ${
                      selected === shape.id
                        ? 'bg-card ring-2 ring-spark shadow-glow'
                        : 'bg-card/60 hover:bg-card'
                    } ${matched.includes(shape.match) ? 'opacity-40' : ''}`}
                    disabled={matched.includes(shape.match)}
                  >
                    <ShapeComponent shape={shape.shape} className={shape.color} />
                  </motion.button>
                ))}
              </div>

              {/* Targets */}
              <div className="flex justify-center gap-6">
                {targets.map((target) => (
                  <motion.button
                    key={target.id}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleTargetClick(target.id)}
                    className={`p-4 rounded-xl border-2 border-dashed transition-all ${target.color} ${
                      matched.includes(target.id)
                        ? 'bg-breakroom/50 border-solid'
                        : 'bg-card/30 hover:bg-card/50'
                    }`}
                  >
                    {matched.includes(target.id) ? (
                      <motion.span
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="text-3xl"
                      >
                        ✓
                      </motion.span>
                    ) : (
                      <div className="w-12 h-12 flex items-center justify-center text-foreground/30">
                        ?
                      </div>
                    )}
                  </motion.button>
                ))}
              </div>

              {allMatched ? (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <GameButton variant="spark" onClick={() => setStep(2)}>
                    Amazing! ✨
                  </GameButton>
                </motion.div>
              ) : (
                <p className="text-foreground/50 text-sm">
                  Tap a shape, then tap where it belongs
                </p>
              )}
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-6"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", bounce: 0.5 }}
                className="text-6xl mb-4"
              >
                🧠
              </motion.div>

              <h3 className="font-display text-2xl text-foreground">
                High score! You're brilliant!
              </h3>
              
              <p className="text-foreground/70 max-w-sm mx-auto">
                Intelligence has many forms. Pattern thinking is one of your superpowers!
              </p>

              <div className="flex items-center justify-center gap-2 text-spark font-display">
                <span className="text-2xl spark-glow">+15</span>
                <span>Sparks</span>
              </div>

              <GameButton variant="spark" onClick={onComplete}>
                Continue Journey →
              </GameButton>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default PuzzleLevel;
