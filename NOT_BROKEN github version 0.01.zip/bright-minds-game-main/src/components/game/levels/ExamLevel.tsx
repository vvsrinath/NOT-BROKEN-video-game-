import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGame } from '@/context/GameContext';
import ThoughtBubble from '../ThoughtBubble';
import GameButton from '../GameButton';

interface ExamLevelProps {
  onComplete: () => void;
}

const ExamLevel: React.FC<ExamLevelProps> = ({ onComplete }) => {
  const { addSparks } = useGame();
  const [step, setStep] = useState(0);
  const [interacted, setInteracted] = useState(false);

  useEffect(() => {
    if (step === 3 && !interacted) {
      addSparks(10);
      setInteracted(true);
    }
  }, [step, interacted, addSparks]);

  return (
    <div className="min-h-screen bg-exam/30 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Desk/paper background */}
      <div className="absolute inset-8 rounded-3xl bg-gradient-to-b from-card/80 to-exam/40 shadow-game" />

      <div className="relative z-10 text-center max-w-2xl mx-auto">
        <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.div
              key="intro"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-6"
            >
              <h2 className="font-display text-3xl md:text-4xl text-foreground">
                ⏰ The Exam Room
              </h2>
              <p className="text-lg text-foreground/70">
                The clock ticks. Time feels heavy.
              </p>
              <GameButton onClick={() => setStep(1)}>Sit Down</GameButton>
            </motion.div>
          )}

          {step === 1 && (
            <motion.div
              key="exam"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              {/* Heavy clock */}
              <motion.div
                animate={{ 
                  scale: [1, 1.1, 1],
                }}
                transition={{ 
                  duration: 1.5,
                  repeat: Infinity,
                }}
                className="text-6xl md:text-8xl"
              >
                ⏰
              </motion.div>

              {/* Pressure words */}
              <div className="flex flex-wrap justify-center gap-4">
                {["Be fast", "Be quiet", "Finish now", "Don't fail"].map((word, i) => (
                  <motion.span
                    key={word}
                    initial={{ opacity: 0 }}
                    animate={{ 
                      opacity: [0.3, 0.7, 0.3],
                    }}
                    transition={{ 
                      delay: i * 0.5,
                      duration: 3,
                      repeat: Infinity,
                    }}
                    className="px-3 py-1 text-foreground/50 font-display text-sm"
                  >
                    {word}
                  </motion.span>
                ))}
              </div>

              {/* Test paper */}
              <motion.div 
                className="bg-card rounded-2xl p-6 max-w-sm mx-auto shadow-game"
                animate={{ y: [0, -3, 0] }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                <div className="space-y-3 text-left">
                  <div className="h-3 bg-foreground/20 rounded w-full" />
                  <div className="h-3 bg-foreground/15 rounded w-4/5" />
                  <div className="h-3 bg-foreground/10 rounded w-3/4" />
                </div>
              </motion.div>

              <GameButton variant="skip" onClick={() => setStep(2)}>
                Take a moment...
              </GameButton>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="thought"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              <ThoughtBubble thought="I know this. I just can't show it yet." />
              
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1 }}
                className="text-foreground/60 text-lg max-w-sm mx-auto"
              >
                Your knowledge is real, even when tests don't show it.
              </motion.p>

              <GameButton onClick={() => setStep(3)}>
                I Am Smart ✨
              </GameButton>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-6"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", bounce: 0.5 }}
                className="text-6xl mb-4"
              >
                💪
              </motion.div>

              <h3 className="font-display text-2xl text-foreground">
                You are more than a test score!
              </h3>
              
              <p className="text-foreground/70 max-w-sm mx-auto">
                Intelligence shows in many ways, not just on paper.
              </p>

              <div className="flex items-center justify-center gap-2 text-spark font-display">
                <span className="text-2xl spark-glow">+10</span>
                <span>Sparks</span>
              </div>

              <GameButton variant="spark" onClick={onComplete}>
                Continue Journey →
              </GameButton>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default ExamLevel;
