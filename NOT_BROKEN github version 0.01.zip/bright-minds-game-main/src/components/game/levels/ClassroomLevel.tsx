import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGame } from '@/context/GameContext';
import ThoughtBubble from '../ThoughtBubble';
import GameButton from '../GameButton';

interface ClassroomLevelProps {
  onComplete: () => void;
}

// Floating letters that represent the jumbled text experience
const FloatingLetter: React.FC<{ letter: string; delay: number }> = ({ letter, delay }) => {
  return (
    <motion.span
      initial={{ opacity: 0, y: 20 }}
      animate={{ 
        opacity: [0.4, 0.8, 0.4],
        y: [0, -10, 5, -5, 0],
        x: [0, 5, -3, 4, 0],
        rotate: [-5, 5, -3, 3, 0],
      }}
      transition={{ 
        delay,
        duration: 4,
        repeat: Infinity,
        repeatType: "reverse",
      }}
      className="inline-block font-display text-4xl md:text-6xl text-foreground/60 mx-1 letter-wobble"
    >
      {letter}
    </motion.span>
  );
};

const ClassroomLevel: React.FC<ClassroomLevelProps> = ({ onComplete }) => {
  const { addSparks } = useGame();
  const [step, setStep] = useState(0);
  const [interacted, setInteracted] = useState(false);

  const words = ["Read", "Listen", "Hurry", "Write", "Focus"];
  const letters = "ABCDMWEP".split("");

  useEffect(() => {
    if (step === 3 && !interacted) {
      addSparks(10);
      setInteracted(true);
    }
  }, [step, interacted, addSparks]);

  return (
    <div className="min-h-screen bg-classroom/30 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Chalkboard effect */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="absolute inset-4 md:inset-12 rounded-3xl bg-gradient-to-br from-secondary/40 to-classroom/60 border-4 border-foreground/10"
      />

      <div className="relative z-10 text-center max-w-2xl mx-auto">
        <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.div
              key="intro"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-6"
            >
              <h2 className="font-display text-3xl md:text-4xl text-foreground">
                📚 The Classroom
              </h2>
              <p className="text-lg text-foreground/70">
                The teacher writes on the board. But the letters... they move.
              </p>
              <GameButton onClick={() => setStep(1)}>Enter</GameButton>
            </motion.div>
          )}

          {step === 1 && (
            <motion.div
              key="letters"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              {/* Floating jumbled letters */}
              <div className="flex flex-wrap justify-center gap-2 mb-8">
                {letters.map((letter, i) => (
                  <FloatingLetter key={i} letter={letter} delay={i * 0.2} />
                ))}
              </div>

              {/* Pressure words */}
              <div className="flex flex-wrap justify-center gap-4">
                {words.map((word, i) => (
                  <motion.span
                    key={word}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ 
                      opacity: [0.5, 1, 0.5],
                      scale: [0.9, 1.1, 0.9],
                    }}
                    transition={{ 
                      delay: i * 0.3,
                      duration: 2,
                      repeat: Infinity,
                    }}
                    className="px-4 py-2 bg-foreground/10 rounded-full text-foreground/70 font-display"
                  >
                    {word}
                  </motion.span>
                ))}
              </div>

              <div className="mt-8">
                <GameButton variant="skip" onClick={() => setStep(2)}>
                  Take a breath...
                </GameButton>
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="thought"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              <ThoughtBubble thought="I am trying..." />
              
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1 }}
                className="text-foreground/60 text-lg"
              >
                Tap anywhere to find calm
              </motion.p>

              <GameButton onClick={() => setStep(3)}>
                Find Your Calm ✨
              </GameButton>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-6"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", bounce: 0.5 }}
                className="text-6xl mb-4"
              >
                ✨
              </motion.div>

              <h3 className="font-display text-2xl text-foreground">
                You did it!
              </h3>
              
              <p className="text-foreground/70 max-w-sm mx-auto">
                The world feels noisy. But you are listening in your own way.
              </p>

              <div className="flex items-center justify-center gap-2 text-spark font-display">
                <span className="text-2xl spark-glow">+10</span>
                <span>Sparks</span>
              </div>

              <GameButton variant="spark" onClick={onComplete}>
                Continue Journey →
              </GameButton>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default ClassroomLevel;
