import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGame } from '@/context/GameContext';
import ThoughtBubble from '../ThoughtBubble';
import GameButton from '../GameButton';

interface BreakRoomLevelProps {
  onComplete: () => void;
}

const activities = [
  { emoji: "🎨", name: "Paint", color: "bg-pink-200" },
  { emoji: "🧱", name: "Build", color: "bg-orange-200" },
  { emoji: "🎵", name: "Music", color: "bg-purple-200" },
  { emoji: "🌱", name: "Garden", color: "bg-green-200" },
  { emoji: "📚", name: "Stories", color: "bg-blue-200" },
  { emoji: "🎭", name: "Play", color: "bg-yellow-200" },
];

const BreakRoomLevel: React.FC<BreakRoomLevelProps> = ({ onComplete }) => {
  const { addSparks } = useGame();
  const [step, setStep] = useState(0);
  const [selectedActivities, setSelectedActivities] = useState<string[]>([]);
  const [interacted, setInteracted] = useState(false);

  const handleActivityClick = (name: string) => {
    if (!selectedActivities.includes(name)) {
      setSelectedActivities([...selectedActivities, name]);
      addSparks(3);
    }
  };

  useEffect(() => {
    if (step === 2 && !interacted) {
      addSparks(10);
      setInteracted(true);
    }
  }, [step, interacted, addSparks]);

  return (
    <div className="min-h-screen bg-breakroom/30 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Cozy room feel */}
      <div className="absolute inset-4 rounded-3xl bg-gradient-to-br from-breakroom/50 via-card/60 to-calm/30" />

      <div className="relative z-10 text-center max-w-2xl mx-auto">
        <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.div
              key="intro"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-6"
            >
              <h2 className="font-display text-3xl md:text-4xl text-foreground">
                🎨 The Break Room
              </h2>
              <p className="text-lg text-foreground/70">
                No rules here. Just create, move, and play.
              </p>
              <GameButton onClick={() => setStep(1)}>Come In</GameButton>
            </motion.div>
          )}

          {step === 1 && (
            <motion.div
              key="activities"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              <div className="flex flex-wrap justify-center gap-3">
                {["Move.", "Create.", "Try."].map((word, i) => (
                  <motion.span
                    key={word}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.2 }}
                    className="font-display text-xl text-foreground/70"
                  >
                    {word}
                  </motion.span>
                ))}
              </div>

              {/* Interactive activities */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 max-w-md mx-auto">
                {activities.map((activity, i) => (
                  <motion.button
                    key={activity.name}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: i * 0.1 }}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => handleActivityClick(activity.name)}
                    className={`${activity.color} rounded-2xl p-4 shadow-game transition-all ${
                      selectedActivities.includes(activity.name)
                        ? 'ring-2 ring-spark scale-105'
                        : ''
                    }`}
                  >
                    <span className="text-4xl block mb-2">{activity.emoji}</span>
                    <span className="font-display text-sm text-foreground/70">
                      {activity.name}
                    </span>
                    {selectedActivities.includes(activity.name) && (
                      <motion.span
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="block text-spark mt-1"
                      >
                        +3 ✨
                      </motion.span>
                    )}
                  </motion.button>
                ))}
              </div>

              <ThoughtBubble thought="Here, I feel good." delay={0.5} />

              <GameButton onClick={() => setStep(2)}>
                I Love This ✨
              </GameButton>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-6"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", bounce: 0.5 }}
                className="text-6xl mb-4"
              >
                🌈
              </motion.div>

              <h3 className="font-display text-2xl text-foreground">
                Everyone has a place where they shine!
              </h3>
              
              <p className="text-foreground/70 max-w-sm mx-auto">
                You tried {selectedActivities.length || "some"} fun activities. 
                Your creativity is your power!
              </p>

              <div className="flex items-center justify-center gap-2 text-spark font-display">
                <span className="text-2xl spark-glow">+10</span>
                <span>Sparks</span>
              </div>

              <GameButton variant="spark" onClick={onComplete}>
                Continue Journey →
              </GameButton>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default BreakRoomLevel;
