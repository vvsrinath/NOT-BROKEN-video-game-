import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGame } from '@/context/GameContext';
import GameButton from '../GameButton';
import { FUTURE_PATHS, FINAL_MESSAGES } from '@/types/game';

interface FutureLevelProps {
  onComplete: () => void;
}

const FutureLevel: React.FC<FutureLevelProps> = ({ onComplete }) => {
  const { addSparks } = useGame();
  const [step, setStep] = useState(0);
  const [selectedPath, setSelectedPath] = useState<number | null>(null);
  const [interacted, setInteracted] = useState(false);

  useEffect(() => {
    if (step === 2 && !interacted) {
      addSparks(20);
      setInteracted(true);
    }
  }, [step, interacted, addSparks]);

  return (
    <div className="min-h-screen bg-future/30 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Starry/hopeful background */}
      <div className="absolute inset-0">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0 }}
            animate={{ 
              opacity: [0.2, 0.8, 0.2],
              scale: [1, 1.2, 1],
            }}
            transition={{ 
              duration: 3,
              delay: i * 0.2,
              repeat: Infinity,
            }}
            className="absolute w-2 h-2 rounded-full bg-spark/60"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
          />
        ))}
      </div>
      <div className="absolute inset-4 rounded-3xl bg-gradient-to-t from-future/50 via-card/40 to-transparent" />

      <div className="relative z-10 text-center max-w-3xl mx-auto">
        <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.div
              key="intro"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-6"
            >
              <h2 className="font-display text-3xl md:text-4xl text-foreground">
                ✨ Future Paths
              </h2>
              <p className="text-lg text-foreground/70">
                Different minds create different futures. All are brilliant.
              </p>
              <GameButton onClick={() => setStep(1)}>See the Future</GameButton>
            </motion.div>
          )}

          {step === 1 && (
            <motion.div
              key="paths"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              <h3 className="font-display text-2xl text-foreground mb-8">
                Three children, three amazing futures
              </h3>

              <div className="grid md:grid-cols-3 gap-6">
                {FUTURE_PATHS.map((path, i) => (
                  <motion.button
                    key={path.name}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.2 }}
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setSelectedPath(i)}
                    className={`bg-card/80 backdrop-blur-sm rounded-2xl p-6 shadow-game text-left transition-all ${
                      selectedPath === i ? 'ring-2 ring-spark' : ''
                    }`}
                  >
                    <span className="text-5xl block mb-4">{path.icon}</span>
                    <h4 className="font-display text-xl text-foreground mb-2">
                      {path.name}
                    </h4>
                    <p className="text-foreground/70 text-sm mb-3">
                      {path.description}
                    </p>
                    <span className="inline-block px-3 py-1 bg-spark/20 rounded-full text-spark text-sm font-display">
                      {path.trait}
                    </span>
                  </motion.button>
                ))}
              </div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.8 }}
              >
                <GameButton variant="spark" onClick={() => setStep(2)}>
                  We Are All Smart ✨
                </GameButton>
              </motion.div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="final"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-8"
            >
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", bounce: 0.5 }}
                className="text-8xl mb-6"
              >
                🌟
              </motion.div>

              <div className="space-y-4">
                {FINAL_MESSAGES.map((message, i) => (
                  <motion.p
                    key={message}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.4 }}
                    className={`font-display ${
                      i === FINAL_MESSAGES.length - 1
                        ? 'text-3xl md:text-4xl text-spark font-bold'
                        : 'text-xl text-foreground/80'
                    }`}
                  >
                    {message}
                  </motion.p>
                ))}
              </div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 2 }}
                className="flex items-center justify-center gap-2 text-spark font-display"
              >
                <span className="text-3xl spark-glow">+20</span>
                <span>Final Sparks!</span>
              </motion.div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 2.5 }}
              >
                <GameButton variant="spark" size="lg" onClick={onComplete}>
                  Complete Journey 🎉
                </GameButton>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default FutureLevel;
