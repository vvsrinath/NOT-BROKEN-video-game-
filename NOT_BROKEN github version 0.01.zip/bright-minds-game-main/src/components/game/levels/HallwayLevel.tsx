import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGame } from '@/context/GameContext';
import ThoughtBubble from '../ThoughtBubble';
import GameButton from '../GameButton';

interface HallwayLevelProps {
  onComplete: () => void;
}

const HallwayLevel: React.FC<HallwayLevelProps> = ({ onComplete }) => {
  const { addSparks } = useGame();
  const [step, setStep] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [interacted, setInteracted] = useState(false);

  const handleFlip = () => {
    setIsFlipped(!isFlipped);
    if (!interacted) {
      addSparks(5);
    }
  };

  useEffect(() => {
    if (step === 3 && !interacted) {
      addSparks(10);
      setInteracted(true);
    }
  }, [step, interacted, addSparks]);

  return (
    <div className="min-h-screen bg-hallway/30 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Hallway perspective effect */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-full h-full max-w-4xl bg-gradient-to-b from-hallway/40 to-background/60 rounded-3xl" />
      </div>

      <div className="relative z-10 text-center max-w-2xl mx-auto">
        <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.div
              key="intro"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-6"
            >
              <h2 className="font-display text-3xl md:text-4xl text-foreground">
                🔄 The Hallway
              </h2>
              <p className="text-lg text-foreground/70">
                Signs point different ways. Arrows seem to flip.
              </p>
              <GameButton onClick={() => setStep(1)}>Walk In</GameButton>
            </motion.div>
          )}

          {step === 1 && (
            <motion.div
              key="flip"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              {/* Flippable arrows */}
              <motion.div
                animate={{ rotateY: isFlipped ? 180 : 0 }}
                transition={{ duration: 0.6 }}
                className="flex justify-center gap-8 text-6xl"
              >
                <span>←</span>
                <span>↑</span>
                <span>→</span>
              </motion.div>

              {/* Confusing signs */}
              <div className="flex flex-wrap justify-center gap-4">
                {["Exit", "Room 3", "Library", "Office"].map((sign, i) => (
                  <motion.div
                    key={sign}
                    animate={{ 
                      rotate: isFlipped ? [0, 5, -5, 0] : [0, -3, 3, 0],
                      scale: [1, 1.05, 0.95, 1],
                    }}
                    transition={{ 
                      duration: 2,
                      delay: i * 0.2,
                      repeat: Infinity,
                    }}
                    className="px-4 py-2 bg-card rounded-xl shadow-game text-foreground/70"
                  >
                    {sign}
                  </motion.div>
                ))}
              </div>

              <GameButton variant="secondary" onClick={handleFlip}>
                Flip the World 🔄
              </GameButton>

              <div className="mt-4">
                <GameButton variant="skip" onClick={() => setStep(2)}>
                  It's okay to see differently
                </GameButton>
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="thought"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="space-y-8"
            >
              <ThoughtBubble thought="My mind is fast. I think different." />
              
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1 }}
                className="text-foreground/60 text-lg"
              >
                Sometimes seeing things differently is a superpower
              </motion.p>

              <GameButton onClick={() => setStep(3)}>
                Embrace It ✨
              </GameButton>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-6"
            >
              <motion.div
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: "spring", bounce: 0.5 }}
                className="text-6xl mb-4"
              >
                🌟
              </motion.div>

              <h3 className="font-display text-2xl text-foreground">
                You see the world your way!
              </h3>
              
              <p className="text-foreground/70 max-w-sm mx-auto">
                Different perspectives lead to amazing discoveries.
              </p>

              <div className="flex items-center justify-center gap-2 text-spark font-display">
                <span className="text-2xl spark-glow">+10</span>
                <span>Sparks</span>
              </div>

              <GameButton variant="spark" onClick={onComplete}>
                Continue Journey →
              </GameButton>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default HallwayLevel;
