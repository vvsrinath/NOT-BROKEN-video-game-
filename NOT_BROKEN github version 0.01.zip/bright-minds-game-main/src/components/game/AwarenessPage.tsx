import { motion } from 'framer-motion';
import GameButton from './GameButton';

interface AwarenessPageProps {
  onBack: () => void;
}

const sections = [
  {
    title: "For Teachers",
    icon: "👩‍🏫",
    color: "bg-classroom/40",
    points: [
      "ADHD and Dyslexia are not about being lazy or not trying hard enough",
      "These students often think differently and creatively",
      "Small changes like extra time or verbal instructions can make a big difference",
      "Focus on strengths, not just challenges",
      "Celebrate effort, not just results",
    ],
  },
  {
    title: "For Parents",
    icon: "👨‍👩‍👧",
    color: "bg-breakroom/40",
    points: [
      "Your child's brain works differently, not wrongly",
      "Many successful people have ADHD or Dyslexia",
      "Patience and understanding go a long way",
      "Find activities where your child feels confident",
      "Work with teachers as a team",
    ],
  },
  {
    title: "For NGOs & Schools",
    icon: "🏫",
    color: "bg-future/40",
    points: [
      "Early identification helps, but avoid labeling",
      "Create inclusive classrooms with flexible teaching methods",
      "Train teachers on neurodiversity",
      "Use games and visual learning",
      "Celebrate different kinds of intelligence",
    ],
  },
];

const myths = [
  { myth: "ADHD means low intelligence", truth: "ADHD is unrelated to IQ" },
  { myth: "Dyslexia is just reading backwards", truth: "Dyslexia affects how the brain processes language" },
  { myth: "They'll grow out of it", truth: "These are lifelong differences, but skills improve with support" },
  { myth: "It's caused by bad parenting", truth: "These are neurological differences present from birth" },
];

const AwarenessPage: React.FC<AwarenessPageProps> = ({ onBack }) => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-muted/30 to-background py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <GameButton variant="skip" onClick={onBack} className="mb-8">
            ← Back to Game
          </GameButton>
          
          <h1 className="font-display text-4xl md:text-5xl text-foreground mb-4">
            Understanding Different Minds
          </h1>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            Simple information for teachers, parents, and organizations about ADHD and Dyslexia. No medical words, just understanding.
          </p>
        </motion.div>

        {/* Sections */}
        <div className="space-y-8 mb-12">
          {sections.map((section, i) => (
            <motion.div
              key={section.title}
              initial={{ opacity: 0, x: i % 2 === 0 ? -30 : 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.2 }}
              className={`${section.color} rounded-3xl p-6 md:p-8`}
            >
              <div className="flex items-center gap-4 mb-6">
                <span className="text-4xl">{section.icon}</span>
                <h2 className="font-display text-2xl text-foreground">
                  {section.title}
                </h2>
              </div>
              <ul className="space-y-3">
                {section.points.map((point, j) => (
                  <motion.li
                    key={j}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.3 + j * 0.1 }}
                    className="flex items-start gap-3 text-foreground/80"
                  >
                    <span className="text-spark mt-1">✦</span>
                    <span>{point}</span>
                  </motion.li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        {/* Myths vs Truth */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="bg-card rounded-3xl p-6 md:p-8 shadow-game mb-12"
        >
          <h2 className="font-display text-2xl text-foreground mb-6 text-center">
            Common Misunderstandings
          </h2>
          <div className="grid md:grid-cols-2 gap-4">
            {myths.map((item, i) => (
              <div key={i} className="bg-muted/50 rounded-2xl p-4">
                <p className="text-destructive/80 text-sm mb-2 line-through">
                  ✗ {item.myth}
                </p>
                <p className="text-breakroom-foreground font-medium">
                  ✓ {item.truth}
                </p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Final message */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="text-center space-y-6"
        >
          <h3 className="font-display text-3xl text-spark">
            Different brain. Different strength.
          </h3>
          <p className="text-foreground/70">
            Change the system, not the child.
          </p>
          <GameButton variant="spark" onClick={onBack}>
            Back to Game ✨
          </GameButton>
        </motion.div>
      </div>
    </div>
  );
};

export default AwarenessPage;
