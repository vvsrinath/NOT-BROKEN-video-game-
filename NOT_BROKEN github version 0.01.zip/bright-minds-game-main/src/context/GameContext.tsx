import React, { createContext, useContext, useState, useCallback } from 'react';
import { GameState } from '@/types/game';

interface GameContextType {
  gameState: GameState;
  addSparks: (amount: number) => void;
  completeLevel: (levelId: number) => void;
  goToLevel: (levelId: number) => void;
  startGame: () => void;
  resetGame: () => void;
}

const initialState: GameState = {
  currentLevel: 0,
  sparks: 0,
  completedLevels: [],
  isPlaying: false,
};

const GameContext = createContext<GameContextType | undefined>(undefined);

export const GameProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [gameState, setGameState] = useState<GameState>(initialState);

  const addSparks = useCallback((amount: number) => {
    setGameState(prev => ({
      ...prev,
      sparks: prev.sparks + amount, // Sparks only go up, never down!
    }));
  }, []);

  const completeLevel = useCallback((levelId: number) => {
    setGameState(prev => ({
      ...prev,
      completedLevels: prev.completedLevels.includes(levelId)
        ? prev.completedLevels
        : [...prev.completedLevels, levelId],
      currentLevel: Math.min(levelId + 1, 6),
    }));
  }, []);

  const goToLevel = useCallback((levelId: number) => {
    setGameState(prev => ({
      ...prev,
      currentLevel: levelId,
      isPlaying: true,
    }));
  }, []);

  const startGame = useCallback(() => {
    setGameState(prev => ({
      ...prev,
      isPlaying: true,
      currentLevel: 1,
    }));
  }, []);

  const resetGame = useCallback(() => {
    setGameState(initialState);
  }, []);

  return (
    <GameContext.Provider value={{
      gameState,
      addSparks,
      completeLevel,
      goToLevel,
      startGame,
      resetGame,
    }}>
      {children}
    </GameContext.Provider>
  );
};

export const useGame = () => {
  const context = useContext(GameContext);
  if (!context) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
};
