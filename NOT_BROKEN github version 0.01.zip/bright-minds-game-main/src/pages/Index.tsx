import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { GameProvider, useGame } from '@/context/GameContext';
import WelcomeScreen from '@/components/game/WelcomeScreen';
import GameScreen from '@/components/game/GameScreen';
import LevelSelect from '@/components/game/LevelSelect';
import EndScreen from '@/components/game/EndScreen';
import AwarenessPage from '@/components/game/AwarenessPage';
import SparkCounter from '@/components/game/SparkCounter';

type Screen = 'welcome' | 'playing' | 'levels' | 'end' | 'awareness';

const GameContent = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>('welcome');
  const { gameState, startGame, goToLevel, resetGame } = useGame();

  const handleStart = () => {
    startGame();
    setCurrentScreen('playing');
  };

  const handleLevelSelect = (levelId: number) => {
    goToLevel(levelId);
    setCurrentScreen('playing');
  };

  const handleGameComplete = () => {
    setCurrentScreen('end');
  };

  const handleRestart = () => {
    resetGame();
    setCurrentScreen('welcome');
  };

  return (
    <div className="min-h-screen">
      {/* Show spark counter when playing or at end */}
      {(currentScreen === 'playing' || currentScreen === 'end') && <SparkCounter />}

      <AnimatePresence mode="wait">
        {currentScreen === 'welcome' && (
          <motion.div
            key="welcome"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <WelcomeScreen
              onStart={handleStart}
              onLevelSelect={() => setCurrentScreen('levels')}
              onAwareness={() => setCurrentScreen('awareness')}
            />
          </motion.div>
        )}

        {currentScreen === 'levels' && (
          <motion.div
            key="levels"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <LevelSelect
              onLevelSelect={handleLevelSelect}
              onBack={() => setCurrentScreen('welcome')}
            />
          </motion.div>
        )}

        {currentScreen === 'playing' && (
          <motion.div
            key="playing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <GameScreen
              onBackToMenu={() => setCurrentScreen('welcome')}
              onComplete={handleGameComplete}
            />
          </motion.div>
        )}

        {currentScreen === 'end' && (
          <motion.div
            key="end"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <EndScreen
              onRestart={handleRestart}
              onAwareness={() => setCurrentScreen('awareness')}
            />
          </motion.div>
        )}

        {currentScreen === 'awareness' && (
          <motion.div
            key="awareness"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <AwarenessPage onBack={() => setCurrentScreen('welcome')} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const Index = () => {
  return (
    <GameProvider>
      <GameContent />
    </GameProvider>
  );
};

export default Index;
